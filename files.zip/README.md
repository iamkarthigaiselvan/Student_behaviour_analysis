# Student Learning Behaviour Clustering

> Unsupervised machine learning project that segments students into distinct learning personas using behavioural engagement data.

## Overview

This project applies **5 clustering algorithms** to the xAPI Educational Mining dataset to uncover hidden patterns in how students engage with learning management systems (LMS). The goal is to automatically group students into actionable personas — from *Disengaged Learners* to *High Achievers* — without any labelled data.

---

## Algorithms Used

| Algorithm | Type | Key Strength |
|---|---|---|
| K-Means | Partition-based | Fast, interpretable |
| Mini-Batch K-Means | Partition-based | Scales to large data |
| Agglomerative Clustering | Hierarchical | Reveals nested structure |
| DBSCAN | Density-based | Finds outliers / irregular shapes |
| Gaussian Mixture Model | Probabilistic | Soft cluster assignments |

---

## Dataset

### Primary: xAPI-Edu-Data (Kaggle)
- **480 students**, 16 features
- Source: [Kaggle — xAPI-Edu-Data](https://www.kaggle.com/datasets/aljarah/xAPI-Edu-Data)
- Features include: raised hands, visited resources, announcements viewed, discussion participation, parent involvement, absence days

### Alternative Advanced Datasets
| Dataset | Size | Source |
|---|---|---|
| Open University Learning Analytics (OULAD) | 32,593 students | [Kaggle](https://www.kaggle.com/datasets/anlgrbz/student-demographics-online-education-dataoulad) |
| Student Performance (UCI) | 649 students | [UCI ML Repo](https://archive.ics.uci.edu/ml/datasets/Student+Performance) |
| EdNet (KT4) | 131M interactions | [GitHub](https://github.com/riiid/ednet) |

---

## Setup

```bash
git clone https://github.com/YOUR_USERNAME/student-learning-clustering.git
cd student-learning-clustering
pip install -r requirements.txt
```

### Download the dataset (optional)

```bash
pip install kaggle
kaggle datasets download -d aljarah/xAPI-Edu-Data -p data/ --unzip
```

> If the dataset is not present, the script generates a realistic synthetic dataset automatically.

---

## Run the Project

```bash
# Full analysis (generates all 9 visualizations)
python clustering_analysis.py

# Interactive Jupyter Notebook
jupyter notebook Student_Clustering.ipynb
```

---

## Project Structure

```
student-learning-clustering/
├── clustering_analysis.py       # Main analysis script
├── Student_Clustering.ipynb     # Interactive notebook
├── requirements.txt             # Dependencies
├── data/
│   └── xAPI-Edu-Data.csv        # Place dataset here
└── outputs/
    ├── 01_optimal_k.png         # Elbow + Silhouette + DB curves
    ├── 02_clustering_comparison.png  # 5 algorithms + t-SNE
    ├── 03_dendrogram.png        # Hierarchical dendrogram
    ├── 04_correlation_heatmap.png
    ├── 05_radar_charts.png      # Per-cluster engagement radars
    ├── 06_algorithm_comparison.png
    ├── 07_cluster_distribution.png
    ├── 08_pca_3d.png            # 3D PCA scatter
    ├── 09_dashboard.png         # Summary dashboard
    ├── clustered_students.csv   # Data with cluster labels
    ├── cluster_profiles.csv     # Mean feature per cluster
    └── algorithm_evaluation.csv # Metrics table
```

---

## Key Findings (sample run)

- **Optimal clusters**: 4–5 using Silhouette score
- **Best algorithm**: Gaussian Mixture (highest Silhouette on this data)
- **Cluster personas identified**:
  - *Disengaged Learner* — low participation, high absences
  - *Passive Observer* — watches resources but doesn't interact
  - *Average Student* — moderate across all features
  - *Active Participant* — high discussion and announcements
  - *High Achiever* — maximum engagement across all dimensions

---

## Evaluation Metrics

| Metric | What it measures |
|---|---|
| Silhouette Score | How similar a point is to its own cluster vs. others (−1 to 1, higher = better) |
| Davies-Bouldin Index | Average similarity between each cluster and its most similar cluster (lower = better) |
| Calinski-Harabasz Index | Ratio of between-cluster to within-cluster variance (higher = better) |

---

## Visualizations

1. **Elbow + Silhouette curve** — Optimal K selection
2. **Clustering comparison grid** — All 5 algorithms on PCA 2D
3. **Dendrogram** — Hierarchical structure
4. **Correlation heatmap** — Feature relationships
5. **Radar charts** — Per-cluster engagement profiles
6. **Algorithm evaluation bars** — Metric comparison
7. **Cluster distribution** — Pie + box plots
8. **3D PCA scatter** — Spatial cluster separation
9. **Summary dashboard** — All key findings

---

## Tech Stack

![Python](https://img.shields.io/badge/Python-3.10+-blue)
![scikit-learn](https://img.shields.io/badge/scikit--learn-1.3+-orange)
![pandas](https://img.shields.io/badge/pandas-2.0+-green)
![matplotlib](https://img.shields.io/badge/matplotlib-3.7+-red)

---

## References

- Amrieh, E. A., Hamtini, T., & Aljarah, I. (2016). Mining Educational Data to Predict Student's academic Performance. *International Journal of Database Theory and Application*.
- Jain, A. K. (2010). Data clustering: 50 years beyond K-means. *Pattern Recognition Letters*.
- Ester, M. et al. (1996). A density-based algorithm for discovering clusters (DBSCAN). *KDD*.

---

## License

MIT — free to use for academic and educational purposes.
